

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">
      <a href="<?php echo e(url('admin/kategori-barang.index')); ?>"
        class="btn btn-seconndary">KEMBALI</a>

      <div class="d-flex justify-content-between align-items-center my-3">
        <div>
            <h2 class="mb-0 fw-bold">Tambah Kategori Barang</h2>
        </div>
      </div>

      <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>        
      <?php endif; ?>

        <form class="card" 
          action="<?php echo e(url('admin/kategori-barang')); ?>"
          method="POST">
          <div class="card-body">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label class="from-label fw-bold text-dark">Nama Kategori Barang</label>
                <input type="text"
                  class="form-control"
                  name="nama"
                  value="<?php echo e(old('nama')); ?>">
            
            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>              
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>      
            </div>
            <div class="mb-3">
                <label class="from-label fw-bold text-dark">Keterangan</label>
                <textarea 
                  class="form-control"
                  name="keterangan" 
                  ><?php echo e(old('keterangan')); ?></textarea>            
            <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>              
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>      
            </div>

        <div class="card-footer bg-light text-end">
            <button type="submit"
              class="btn btn-primary">SIMPAN</button>
        </div>
      </form>
      </div>
    </div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coba2\resources\views/admin/kategori-barang/create.blade.php ENDPATH**/ ?>