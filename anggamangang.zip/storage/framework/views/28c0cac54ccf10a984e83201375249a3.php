

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">
        <div class="d-flex justify-content-between align-intems-center mb-3">
            <div>
                <h2 class="mb-0 fw-bold">Kategori Barang</h2>
            </div>
            <div class="aksi">
                <a href="<?php echo e(url('admin/kategori-barang/tambah')); ?>"
                  class="btn btn-primary">TAMBAH</a>
            </div>
        </div>
        
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        
        <?php if(session('error')): ?>
            <div class="alert alert-success"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h4 class="mb-0 fw-bold text-dark">Daftar Kategori Barang</h4>
        </div>
        <div class="card-body pt-0">
            <table class="table table-bordered table-striped table-hover w-100">
                <thead>
                    <tr>
                        <th style="width: 40px">No</th>
                        <th class="text-center">Nama Kategori</th>
                        <th class="text-center">Keterangan</th>
                        <th class="text-center" style="width: 150px">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $listBarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($Barang->nama); ?></td>
                        <td><?php echo e($Barang->keterangan); ?></td>
                        <td class="text-center">
                            <a href="<?php echo e(url('admin/kategori-barang/' . $Barang->id . '/ubah')); ?>" class="btn btn-secondary">
                                <i class="align-middle" data-feather="edit"></i>
                            </a>
                            <form action="<?php echo e(url('admin/kategori-barang/' . $Barang->id)); ?>" method="POST" class="d-inline-block"
                                onsubmit="return confirm('Apakah anda yakin menghapus data ini ?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">
                                      <i class="align-middle" data-feather="trash-2"></i>
                                </button>
                            </form>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coba2\resources\views/admin/kategori-barang/index.blade.php ENDPATH**/ ?>