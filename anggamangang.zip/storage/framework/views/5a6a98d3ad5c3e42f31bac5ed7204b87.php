<!-- Footer -->      
<footer class="footer">
    <div class="container-fluid">
      <div class="row text-muted">
        <div class="col-6 text-start">
          <p class="mb-0">
            Templatenya pakai
            <a class="text-muted"
              href="https://adminkit.io/"
              target="_blank"><strong>AdminKit</strong></a>
          </p>
        </div>
        <div class="col-6 text-end">
        </div>
      </div>
    </div>
  </footer>
<!-- Footer --><?php /**PATH C:\laragon\www\coba2\resources\views/layouts/admin/footer.blade.php ENDPATH**/ ?>