<nav class="navbar navbar-expand navbar-light navbar-bg">
    <a class="sidebar-toggle js-sidebar-toggle">
      <i class="hamburger align-self-center"></i>
    </a>

    <div class="navbar-collapse collapse">
      <ul class="navbar-nav navbar-align">
        <li class="nav-item dropdown">
          <a class="nav-icon dropdown-toggle d-inline-block d-sm-none"
            href="#"
            data-bs-toggle="dropdown">
            <i class="align-middle"
              data-feather="settings"></i>
          </a>

          <a class="nav-link dropdown-toggle d-none d-sm-inline-flex align-items-center"
            href="#"
            data-bs-toggle="dropdown">
            <div class="d-inline-flex align-items-center">
              <img src="https://hostedboringavatars.vercel.app/api/beam?size=64"
                class="avatar img-fluid me-1 rounded"
                />
              <div class="mx-1">
                <div class="text-dark fw-bold"><?php echo e(Auth::user()->name); ?></div>
                <div class="text-muted" style="font-size: 0.65rem"><?php echo e(Auth::user()->email); ?></div>
              </div>  
              
            </div>
          </a>
          <div class="dropdown-menu dropdown-menu-end me-3 me-sm-0">
            <a class="dropdown-item" href="#">
              <i class="me-1 align-middle"
                data-feather="settings"></i>
              <span>Pengaturan</span>
            </a>
            <div class="dropdown-divider"></div>
            <form action="<?php echo e(url('logout')); ?>"
              method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
              <button class="dropdown-item">
              Log out
              </button>
            </form>
          </div>
        </li>
      </ul>
    </div>
  </nav><?php /**PATH C:\laragon\www\coba2\resources\views/layouts/admin/topbar.blade.php ENDPATH**/ ?>