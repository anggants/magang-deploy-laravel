

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0">
    <div class="card">
        <div class="card-body">INI HALAMAN DASBOR</div>
    </div>
</div>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coba2\resources\views/admin/dasbor.blade.php ENDPATH**/ ?>