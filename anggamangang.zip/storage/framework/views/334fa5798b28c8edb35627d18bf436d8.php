

<?php $__env->startSection('content'); ?>
<div class="col-sm-10 col-md-8 col-lg-6 col-xl-5 mx-auto d-table h-100">
    <div class="d-table-cell align-middle">

        <div class="text-center mt-4">
            <h1 class="h2">Magang Latihan Laravel</h1>
            <p class="lead">Silahkan login untuk melanjutkan</p>
        </div>

    <div class="card">
        <div class="card-body">
            <div class="m-sm-3">
                <form action="<?php echo e(url('login')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input class="form-control form-control-lg"
                            type="email"
                            name="email" 
                            placeholder="masukkan alamat email" 
                            value="<?php echo e(old('email')); ?>"
                            />
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Kata Sandi</label>
                        <input class="form-control form-control-lg" 
                            type="password"
                            name="password" 
                            placeholder="masukkan kata sandi" />
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="d-grid gap-2 mt-3">
                      <button type="submit"
                        class="btn btn-lg btn-primary">MASUK</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.base-blank', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coba2\resources\views/login.blade.php ENDPATH**/ ?>