@extends('layouts.admin.base')

@section('content')
<div class="container-fluid p-0">
    <div class="card">
        <div class="card-body">INI HALAMAN DASBOR</div>
    </div>
</div>    
@endsection
