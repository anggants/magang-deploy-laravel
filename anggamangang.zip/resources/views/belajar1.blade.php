@extends('layouts.base')

@section('judul')
    ini adalah belajar 1
  @endsection

@section('isi-utama')
    ini adalah isi utama
  @endsection

@section('isi-kiri')
    ini adalah isi kiri
  @endsection

@section('isi-kanan')
    ini adalah isi kanan
  @endsection      