<footer class="pt-5 my-3 text-body-secondary border-top">
    dibuat untuk latihan 2023
</footer>